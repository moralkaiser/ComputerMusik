# CSharpSynthForUnity
Ported CSharpSynth Project from http://csharpsynthproject.codeplex.com/ to work in Unity
